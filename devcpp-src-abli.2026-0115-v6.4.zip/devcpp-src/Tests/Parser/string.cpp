#include <string>
using std::string;

int main() {
	string a;
	a.append();
}
