int main() {
	// If statement
	int a = 0;
	bool b = true;
	if(b) {
		a = 2;
	} else {
		a = 3;
	}
	if(a < 3) {
		b = false;
	}
	
	b = a < 3;
	
	// String stuff
	char c[32];
	void* d = (void*)"Hello";
}
