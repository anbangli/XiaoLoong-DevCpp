{
	{
		{
		}
	}
	{
		{
			
		}
	}
	switch(a) {
		case 1: {
			
			break;
		}
		case 2: {
			
			break;
		}
		default: {
			
			break;
		}
	}
	if(aap) {
		
	} else {
		
	}
}

// collapse this one
{
	// leave this one as is
	{
		// collapse this one too
		{
			
		}
	}
}
