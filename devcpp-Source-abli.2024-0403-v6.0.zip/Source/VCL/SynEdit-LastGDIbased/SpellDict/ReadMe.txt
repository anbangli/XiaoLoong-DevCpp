Spell dictionaries are plaintext files
Each word on separate line
For better performance save dictionary as sorted
You need to insert all word form, there is no automatic word form creation mechanism
