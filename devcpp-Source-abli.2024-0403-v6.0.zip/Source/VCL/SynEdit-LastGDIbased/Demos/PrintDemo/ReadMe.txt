PrintDemo
---------

- Needs Delphi Rio or higher (uses TImageCollection and TVirtualImageList).
- Demonstrates components for printing and print preview.

