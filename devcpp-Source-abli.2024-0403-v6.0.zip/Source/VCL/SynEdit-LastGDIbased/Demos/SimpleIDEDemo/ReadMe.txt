SimpleIDEDemo.dpr
-----------------

- Demonstrates how to highlight breakpoint or current lines in different colors
  (as seen in the Delphi IDE).  

- Showcases the new Gutter.  A new custom gutter band that displays debugger information is 
  created and uses the OnPaintLines, OnClick and OnMouseCursor events.
