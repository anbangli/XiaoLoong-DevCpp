Iconset: Essentials (https://www.iconfinder.com/iconsets/essentials-9)
Author: Alice Rizzo (https://www.iconfinder.com/AliceR)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2021-10-29