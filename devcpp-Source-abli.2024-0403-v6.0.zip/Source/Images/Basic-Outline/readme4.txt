Iconset: Web User Interface (https://www.iconfinder.com/iconsets/web-user-interface-10)
Author: design4design (https://www.iconfinder.com/design4design)
License: Creative Commons (Attribution-Noncommercial 3.0 Unported) (http://creativecommons.org/licenses/by-nc/3.0/)
Download date: 2021-10-29