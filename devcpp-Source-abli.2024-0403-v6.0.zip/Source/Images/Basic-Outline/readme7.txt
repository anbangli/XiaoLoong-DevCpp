Iconset: Basic User Interface (https://www.iconfinder.com/iconsets/basic-user-interface-5)
Author: Sabr Studio (https://www.iconfinder.com/perpixel)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
Download date: 2021-10-29