/*
	System header
*/
#include<windows.h>
 #include<windows.h>
 # include<windows.h>
#include <windows.h>
 #include <windows.h>
 # include <windows.h>
#include <windows.h> // comment
 #include <windows.h> // comment
 # include <windows.h> // comment
/*
	Local header
*/
#include"IncludeTestA.h"
 #include"IncludeTestA.h"
 # include"IncludeTestA.h"
#include "IncludeTestA.h"
 #include "IncludeTestA.h"
 # include "IncludeTestA.h"
#include "IncludeTestA.h" // comment
 #include "IncludeTestA.h" // comment
 # include "IncludeTestA.h" // comment
/*
	Local header in folder
*/
#include"Folder\IncludeTestB.h"
 #include"Folder\IncludeTestB.h"
 # include"Folder\IncludeTestB.h"
#include "Folder\IncludeTestB.h"
 #include "Folder\IncludeTestB.h"
 # include "Folder\IncludeTestB.h"
#include "Folder\IncludeTestB.h" // comment
 #include "Folder\IncludeTestB.h" // comment
 # include "Folder\IncludeTestB.h" // comment
