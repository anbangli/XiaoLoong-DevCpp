Iconset: Mini icon set - General / Office (https://www.iconfinder.com/iconsets/mini-icon-set-general-office)
Author: BomSymbols . (https://www.iconfinder.com/korawan_m)
License: Free for commercial use (Include link to authors website) ()
Download date: 2021-10-31