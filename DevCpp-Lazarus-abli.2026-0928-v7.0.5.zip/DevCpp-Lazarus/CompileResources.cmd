path %path%;"c:\Program Files (x86)\Embarcadero\RAD Studio\12.0\bin\"

brcc32 DefaultFiles.rc
brcc32 Icons.rc
pause