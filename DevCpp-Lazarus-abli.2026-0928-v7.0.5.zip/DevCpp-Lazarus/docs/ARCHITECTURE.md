# DevCpp (XiaoLoong Dev-C++) 项目架构分析

> 版本: v7.0 测试版 | 开发框架: Lazarus 4.6 | 编码语言: Object Pascal (Delphi Mode)
> 更新日期: 2026-07-07

---

## 1. 项目概览

### 1.1 背景

DevCpp 是经典的 C/C++ 集成开发环境，最初由 Bloodshed Software 开发，后由 Orwell 接手维护，**当前版本由 XiaoLoong 团队迁移至 Lazarus/Free Pascal 平台**。

项目当前正在进行 **SynEdit → ATSynEdit 重大重构**，同时完成了 Delphi → Lazarus 的平台迁移。

### 1.2 基础信息

| 属性 | 值 |
|------|-----|
| 项目名称 | XiaoLoong Dev-C++ (XL7) |
| 版本 | 7.0 测试版 |
| 源码目录 | `C:\Users\Administrator\WorkBuddy\2026-DevCpp-Lazarus\DevCpp-Lazarus\` |
| 入口文件 | `DevCpp.lpr` |
| 项目文件 | `DevCpp.lpi` (Lazarus Project) |
| 主窗体 | `main.pas` → `TMainForm` |
| 目标输出 | `d:\cc\devcpp\release\DevCpp.exe` |
| 编译器 | Free Pascal 3.2.2 |
| IDE | Lazarus 4.6 |

---

## 2. 项目规模统计

```
总计 Pascal 源文件:     ~85 个 (.pas / .lfm)
核心逻辑文件:           ~75 个
总代码规模:             ~3,000+ KB
主窗体 (main.pas):      ~305 KB (最大单文件)
编辑器 (Editor.pas):    ~122 KB
配置管理 (devcfg.pas):  ~124 KB
词法/解析器 (CppParser): ~101 KB
编译器 (Compiler.pas):  ~54 KB
项目类 (Project.pas):   ~69 KB
编辑器选项 (EditorOptFrm): ~91 KB
```

---

## 3. 核心技术栈

### 3.1 第三方依赖包

项目通过 **Lazarus Online Package Manager** 安装以下包：

| 包名 | 用途 |
|------|------|
| **ATSynEdit** | 现代化语法高亮编辑器控件（TATSynEdit），CudaText 编辑器核心引擎，替代旧版 SynEdit |
| **ATSynEdit_Ex** | ATSynEdit 扩展包（附加功能） |
| **ATSynEdit_Cmp** | ATSynEdit 组件集合 |
| **EControl** | 语法高亮和代码编辑组件库（配合 ATSynEdit 使用） |
| **EncConv** | 字符编码转换库（UTF-8 ↔ ANSI ↔ Unicode 等） |

### 3.2 内置/辅助工具

| 工具 | 来源/路径 | 用途 |
|------|----------|------|
| `ConsolePauser.exe` | Tools\ | 运行时控制台程序结束后暂停 |
| `devcppPortable.exe` | Tools\ | 便携模式启动器 |
| `Packman.exe` | Tools\ | .pak 插件包管理器（遗留） |
| `GitPush.exe` | Tools\ | 自动 Git 提交推送 |
| `KeywordHighlighter.exe` | Tools\ | 关键词哈希表生成工具 |
| `TextDiff.exe` | Tools\ | 文件差异比较工具 |

### 3.3 外部编译器集成

DevCpp 本身是 IDE，它调用外部 MinGW GCC 工具链：

| 工具 | 默认程序名 | 用途 |
|------|----------|------|
| C 编译器 | `gcc.exe` | C 源码编译 |
| C++ 编译器 | `g++.exe` | C++ 源码编译 |
| 调试器 | `gdb.exe` / `gdb32.exe` | GDB 调试 |
| 资源编译器 | `windres.exe` | Windows 资源文件编译 |
| Make 程序 | `mingw32-make.exe` | 构建自动化 |
| 性能分析 | `gprof.exe` | 程序性能分析 |

---

## 4. 模块架构图

```
┌──────────────────────────────────────────────────────────────┐
│                    DevCpp.lpr (程序入口)                      │
│  · 单例检测 · INI 路径解析 · 配置加载 · 主窗体创建            │
└──────────────────────────┬───────────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────────┐
│                main.pas (TMainForm) — 核心                 │
│  最大模块 (~305KB)，协调所有子模块的中央调度器                 │
└────┬────────────┬──────────┬──────────┬──────────┬─────────┘
     │            │          │          │          │
     ▼            ▼          ▼          ▼          ▼
┌─────────┐  ┌─────────┐ ┌─────────┐ ┌────────┐ ┌──────────┐
│ Editor  │  │Compiler │ │Debugger │ │Project │ │ ClassBrw │
│EditorList│  │  .pas   │ │  .pas   │ │  .pas  │ │  owser  │
│  ~122KB │  │ ~54KB   │ │ ~13KB   │ │ ~69KB  │ │  ~30KB  │
└────┬────┘  └────┬────┘ └────┬────┘ └───┬────┘ └────┬─────┘
     │            │           │          │            │
     ▼            ▼           ▼          │            ▼
┌──────────┐  ┌────────┐ ┌────────┐   │     ┌──────────────┐
│ATSynEdit │  │TCompiler│ │TDebugger│   │     │ TCppParser   │
│(编辑器)   │  │(编译)   │ │(调试)   │   │     │ (~101KB)     │
└────┬─────┘  └────────┘ └────────┘   │     │  ┌──────────┐│
     │                                │     │  │Tokenizer ││
     ▼                                │     │  │ Preproc  ││
┌──────────────────────────┐          │     │  └──────────┘│
│    智能编辑增强模块        │          │     └──────────────┘
│ ┌────────────┐ ┌────────┐│          │
│ │CodeToolTip │ │ Code   ││          │     ▼
│ │  .pas      │ │Complet ││          │ ┌──────────────┐
│ │ ~31KB      │ │ ion.pas││          │ │  CBUtils     │
│ └────────────┘ └────────┘│          │ │ (~15KB)      │
└──────────────────────────┘          │ │ StatementList│
                                     │ └──────────────┘
┌──────────────────────────────────────────────────────────┐
│                    核心支撑模块                            │
├───────────────┬────────────────┬─────────────────────────┤
│  devcfg.pas   │  Project.pas   │  EditorList.pas        │
│  配置管理 (~124KB)│  项目文件管理  │  多文档编辑器列表管理   │
│  · TdevData   │  · TProject    │  · TEditorList          │
│  · TdevCompilerSet │ · TProjUnit │ · TLayoutShowType      │
├───────────────┼────────────────┼─────────────────────────┤
│  Utils.pas    │  CFGData.pas   │  CodeInsList.pas       │
│  工具函数库    │  配置数据结构   │  代码插入片段列表        │
│  · 文件操作   │  · 编译器选项   │                        │
│  · 进程执行   │  · 环境设置    │                         │
├───────────────┼────────────────┼─────────────────────────┤
│  DevRun.pas   │  devExec.pas   │  Macros.pas             │
│  程序运行器   │  外部进程执行   │  宏替换处理              │
├───────────────┴────────────────┴─────────────────────────┤
│                    解析/代码分析模块                        │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────┐  │
│  │ CppParser   │  │ CppPreproc   │  │ CppTokenizer    │  │
│  │ (~101KB)    │  │ (~34KB)      │  │ (~22KB)         │  │
│  │ C++词法解析  │  │ 预处理指令解析│  │ 词法分词器       │  │
│  └─────────────┘  └──────────────┘  └─────────────────┘  │
└─────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│                    UI 窗体模块 (按功能)                     │
├────────────────┬───────────────────────────────────────────┤
│ 文件操作类      │ NewProjectFrm, RemoveUnitFrm, FileAssocs   │
│ 编辑辅助类      │ EditorOptFrm, CodeInsList, IncrementalFrm │
│ 搜索替换类      │ FindFrm, GotoLineFrm                      │
│ 项目配置类      │ ProjectOptionsFrm, CompOptionsFrm         │
│ 环境工具类      │ EnviroFrm, ToolFrm, ShortcutsFrm         │
│ 调试视图类      │ CPUFrm, ExceptionFrm, ProcessListFrm     │
│ 导入导出类      │ ImportMSVCFrm, ImportCBFrm, PrintFrm     │
│ 类/代码生成类   │ NewClassFrm, NewFunctionFrm, NewVarFrm   │
│                │ NewTemplateFrm                             │
│ 其他工具类      │ LangFrm, AboutFrm, TipOfTheDayFrm        │
│                │ ViewToDoFrm, AddToDoFrm, FilePropertiesFrm │
│                │ FileEncodingFrm, HomepageFrm, IconFrm      │
│                │ CodeCompletionForm, FormatterOptionsFrm    │
├────────────────┴───────────────────────────────────────────┤
│  数据模块 (DataModule)                                      │
│  DataFrm — dmMain (数据模块，包含图片列表、工具栏图像等)       │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│                    配置/资源/多语言                         │
├────────────────────────────────────────────────────────────┤
│ devcfg.pas    — devCFG 单元 (全局配置，~124KB)               │
│ CFGData.pas   — 配置数据结构定义                             │
│ LangIDs.inc   — 语言字符串表常量 (66KB，多语言支持)          │
│ MultiLangSupport.pas — 多语言切换支持                        │
│ Images/       — 主题图像资源 (Gnome/Modern/NewLook)         │
│ lexers/       — EControl 词法定界文件 (.lcf: C++, RC)        │
│ Tools/        — 辅助可执行工具                               │
│ Templates/    — 新建项目/文件模板                            │
│ Tests/        — 单元测试代码                                │
└────────────────────────────────────────────────────────────┘
```

---

## 5. 核心模块详细分析

### 5.1 主程序入口 — `DevCpp.lpr`

```pascal
program DevCpp;
uses
  LCLIntf, LCLType, Forms, Interfaces, sysUtils, Windows,
  main,           // 主窗体
  devcfg,         // 全局配置
  CFGData,         // 配置数据结构
  FileAssocs,     // 文件关联
  ExceptionFrm,    // 异常处理窗体
  Instances,      // 单例管理
  CodeToolTip,    // 代码提示
  CppPreprocessor // 预处理支持
```

**启动流程：**
1. `GetPreviousInstance` — 检测单例运行
2. 解析 INI 配置文件路径（支持 `-c <dir>` 便携模式和默认 `%APPDATA%\Dev-Cpp` 模式）
3. `devData.ReadSelf` — 加载配置
4. `CreateOptions` — 初始化选项
5. `Application.CreateForm(TMainForm, MainForm)` — 创建主窗体

### 5.2 主窗体 — `main.pas` (TMainForm, ~305KB)

DevCpp 的中央调度器，**是整个项目最大的模块**。包含：

- **菜单系统**：文件、编辑、搜索、视图、项目、执行、工具、窗口、帮助
- **编辑器管理**：多文档界面，支持标签页和分栏布局
- **项目管理**：项目树形视图管理
- **调试控制**：断点、监视、堆栈视图
- **编译器集成**：编译、运行、调试的一键执行
- **文件监控**：热重载和外部文件变更检测

### 5.3 编辑器模块 — `Editor.pas` (TEditor, ~122KB)

封装 ATSynEdit 编辑器核心：

```
TEditor
  ├── fInProject: boolean
  ├── fSynEdit: TATSynEdit              ← 核心编辑器组件
  ├── fAdapter: TATSynEdit_Adapter_EControl  ← 语法高亮适配器
  ├── fCompletionPopup: TCodeCompletionForm
  ├── fToolTip: TCodeToolTip
  ├── 断点管理 (Breakpoints)
  ├── 书签管理 (Bookmarks)
  ├── 代码折叠 (Folding)
  ├── 多光标支持 (Multiple Carets)
  └── 事件处理 (OnChange, OnKeyDown, OnPaintLine...)
```

### 5.4 编译器模块 — `Compiler.pas` (TCompiler, ~54KB)

```
TCompiler
  ├── fCompilerSet: TdevCompilerSet     ← 编译器配置集
  ├── fTarget: TTarget                   ← ctInvalid/ctNone/ctFile/ctProject
  ├── fMakefile: String
  ├── 编译参数构建
  ├── 编译输出解析 (GCC 错误格式解析)
  └── 事件: OnLogEntry, OnOutput, OnCompEnd, OnCompSuccess
```

### 5.5 调试器模块 — `Debugger.pas` + `DebugReader.pas`

```
TDebugger
  ├── fReader: TDebugReader        ← GDB 输出管道读取
  ├── fBreakPointList: TList      ← 断点列表
  ├── fWatchVarList: TList        ← 监视变量列表
  ├── 断点管理
  ├── 变量求值
  └── 堆栈追踪
```

### 5.6 C++ 代码解析器 — `CppParser.pas` (~101KB)

```
TCppParser
  ├── fTokenizer: TCppTokenizer        ← 词法分词
  ├── fPreprocessor: TCppPreprocessor ← 预处理
  ├── fStatementList: TStatementList  ← 解析结果
  ├── fIncludesList: TList             ← #include 依赖
  ├── fScannedFiles: TStringList
  ├── fProjectIncludePaths / fIncludePaths
  └── 解析入口: ParseFile(), ParseSource()
```

解析流程：`CppTokenizer` (分词) → `CppPreprocessor` (预处理) → `TCppParser` (语义分析) → `StatementList` (结果存储)

### 5.7 代码补全 — `CodeCompletion.pas` (~25KB)

基于 `CppParser` 解析结果，提供：
- 成员列表自动弹出
- 符号查找
- 参数提示

### 5.8 代码提示 — `CodeToolTip.pas` (~31KB)

- 函数签名显示
- 变量类型提示
- 鼠标悬停识别（标识符、预处理指令）

### 5.9 类浏览器 — `ClassBrowser.pas` (~30KB)

树形视图展示 C++ 代码结构：
```
Classes (类)
  ├── Functions (函数)
  ├── Variables (成员变量)
  ├── Enums (枚举)
  ├── Structs (结构体)
  └── Inherited (继承)
Namespaces (命名空间)
Macros (宏定义)
...
```

### 5.10 配置管理 — `devcfg.pas` (~124KB)

```
devCFG 单元（核心配置中心）
  ├── TdevData (全局数据类)
  │    ├── CompilerSet[0..9]    ← 最多 10 个编译器配置
  │    ├── DefaultCompiler      ← 默认编译器
  │    ├── INIFileName          ← 配置文件路径
  │    └── 编辑器/环境/快捷键配置
  │
  └── TdevCompilerSet (编译器配置类)
       ├── Executables: gcc/g++/gdb/make/windres/gprof
       ├── Directories: Bin/C/Include/Lib
       ├── Predefined: fDefines (预定义宏: __cplusplus, WIN32 等)
       └── fOptions: TList<TCompilerOption>
```

### 5.11 项目管理 — `Project.pas` (~69KB)

```
TProject
  ├── TProjUnit (项目中的单个源文件)
  │    ├── fFileName, fEditor, fCompile, fLink
  │    └── fBuildCmd (自定义编译命令)
  └── TUnitList (文件列表)
       ├── Add/Remove/IndexOf
       └── 文件顺序管理（优先级）
```

---

## 6. 数据流与交互关系

### 6.1 编译流程

```
用户点击"编译"
    ↓
MainForm.actCompileExecute()
    ↓
TCompiler.Compile()
    ├→ TdevCompilerSet.GetCompilerCmd()   ← 读取编译器参数
    ├→ TProject.GetMakeFile()              ← 生成 Makefile
    └→ RunAndGetOutput()                   ← 调用 gcc/g++/make
    ↓
GDB 解析错误输出
    ↓
MainForm.UpdateCaption / 错误行高亮
```

### 6.2 代码补全流程

```
用户在编辑器中输入 "obj."
    ↓
ATSynEdit 检测到触发字符 '.'
    ↓
CodeCompletion.RequestCompletion()
    ├→ CppParser.LocateToken()             ← 定位当前符号
    ├→ CppParser.GetStatement()             ← 获取上下文
    └→ StatementList 查找成员
    ↓
CodeCompletionForm 弹出列表
    ↓
用户选择 → TEditor.InsertCompletion()
```

### 6.3 调试流程

```
用户点击"调试"
    ↓
MainForm.actDebugExecute()
    ├→ TDebugger.Start(gdb)                ← 启动 GDB
    └→ fReader.BeginRead()                 ← 异步读取 GDB 输出
    ↓
GDB 断点命中
    ↓
TDebugger.ParseBreakPoint()
    ↓
MainForm 更新断点视图 / 代码行跳转
```

---

## 7. 文件类型关联

| 扩展名 | 文件类型 | 处理方式 |
|--------|---------|---------|
| `.dev` | DevCpp 项目文件 | `Project.pas` 解析 |
| `.cpp/.c/.cc/.cxx` | C++/C 源文件 | `CppParser` + ATSynEdit |
| `.h/.hpp/.hh` | 头文件 | `CppParser` + ATSynEdit |
| `.rc` | 资源脚本 | `windres` 编译 |
| `.template` | 新建项目模板 | `Templates.pas` |
| `.lcf` | EControl 词法定界 | 语法高亮 |
| `.ini` | 配置文件 | `devcfg.pas` |
| `.dev` (旧) | 项目文件 | `ImportCBFrm` / `ImportMSVCFrm` 导入 |

---

## 8. 架构特点与设计亮点

### 8.1 架构分层清晰

| 层次 | 模块 | 说明 |
|------|------|------|
| UI 层 | main.pas + 所有 Frm 单元 | 窗体展示，用户交互 |
| 业务层 | Editor, Compiler, Debugger, Project | 核心功能逻辑 |
| 解析层 | CppParser, CppTokenizer, CppPreprocessor | 代码分析 |
| 数据层 | devcfg, CFGData, Project | 配置与项目管理 |
| 工具层 | Utils, CBUtils, StatementList | 通用工具函数 |

### 8.2 事件驱动设计

大量使用 `procedure of object` 事件回调：
```pascal
TLogEntryEvent = procedure(const Msg: String) of object;
TOutputEvent = procedure(const _Line, _Col, _Unit, _Message: String) of object;
TCompEndEvent = procedure of object;
TEvalReadyEvent = procedure(const evalvalue: AnsiString) of object;
```

### 8.3 单例模式

通过 Windows API `FindWindow` 检测已有实例，确保同时只运行一个 DevCpp 进程。

### 8.4 配置文件可移植

支持 `-c <目录>` 命令行参数，可将配置存储在程序目录而非 `%APPDATA%`，实现真正的即插即用。

### 8.5 多编译器配置

支持同时配置最多 **10 套不同的编译器工具链**（如 MinGW、TDM-GCC 等），随时切换。

---

## 9. 当前开发状态与待办

### 9.1 已完成 (2026-07-07)

- ✅ Delphi → Lazarus 4.6 迁移
- ✅ SynEdit → ATSynEdit 编辑器替换
- ✅ EControl 语法高亮集成
- ✅ EncConv 编码转换支持
- ✅ 多语言界面框架

### 9.2 进行中 / 待办

- 🔄 完善 HTML/RTF/TeX 导出功能（当前已禁用）
- 🔄 类浏览器 (ClassBrowser) 稳定化
- 🔄 VCL Styles 主题支持（Delphi 特定，待迁移）
- 📋 TODO: 编译器切换时自动重新解析代码
- 📋 TODO: 查找结果列表绘制优化
- 📋 TODO: 相同词高亮（选中词高亮）
- 📋 TODO: 文件重命名功能 (MoveFile)
- 📋 TODO: 自定义关键词高亮器
- 📋 TODO: CPU 调试窗口跳转帧
- 📋 TODO: 条件断点

---

## 10. 快速编译指南

```powershell
# 1. 安装依赖包 (Lazarus IDE → Packages → Online Package Manager)
#    ATSynEdit, EControl, EncConv

# 2. 添加项目依赖 (Project → Project Inspector → Add Requirement)
#    atsynedit_cmp, atsynedit_ex, atsynedit, econtrol, encconv

# 3. 下载词法文件 (EControl 需要)
#    https://sourceforge.net/projects/cudatext/files/addons/lexers/
#    → C++.lcf, C++.lcf 放入 lexers/ 目录

# 4. 用 Lazarus 打开 DevCpp.lpi，编译运行
```

---

*文档生成时间: 2026-07-07*
*分析工具: 人工代码审查 + 目录结构扫描*
