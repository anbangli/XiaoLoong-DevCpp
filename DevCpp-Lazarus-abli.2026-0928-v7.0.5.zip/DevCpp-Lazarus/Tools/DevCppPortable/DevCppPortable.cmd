set curpath=%~dp0
cd %curpath%
start DevCpp.exe -c config