{
    This file is part of Dev-C++
    Copyright (c) 2004 Bloodshed Software

    Dev-C++ is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Dev-C++ is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Dev-C++; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
}

unit AboutFrm;

interface

uses
  {$IFDEF MSWINDOWS}Windows{$ELSE}LCLIntf, LCLType{$ENDIF}, SysUtils, Classes, version, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls;

type
  TAboutForm = class(TForm)
    lblVersion: TLabel;
    btnOk: TBitBtn;
    lblCopyright: TLabel;
    grpLinks: TGroupBox;
    lblBlood: TLabel;
    lblBloodURL: TLabel;
    lblResources: TLabel;
    lblResourcesURL: TLabel;
    lblBlog: TLabel;
    lblBlogURL: TLabel;
    btnAuthors: TBitBtn;
    btnUpdateCheck: TBitBtn;
    timerFish: TTimer;
    pnlFish: TPanel;
    FishImage: TImage;
    imgBanner: TImage;
    bvNew: TBevel;
    lblSubreddit: TLabel;
    lblSubredditURL: TLabel;
    lblRepository: TLabel;
    lblRepositoryURL: TLabel;
    lblTDM: TLabel;
    lblTDMURL: TLabel;
    lblPost4992: TLabel;
    lblCompilers: TLabel;
    lblPre4992: TLabel;
    bvCompilers: TBevel;
    imgDonate: TImage;
    lblLicense: TLabel;
    txtLicense: TMemo;
    lblLicenseURL: TLabel;
    Label1: TLabel;
    Bevel1: TBevel;
    lblWebSiteURL: TLabel;
    lblMinGWURL: TLabel;
    lblMinGW: TLabel;
    lblWebsite: TLabel;
    lblEmail: TLabel;
    edtEmail: TEdit;
    lblBuild: TLabel;
    procedure URLLabelClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnAuthorsClick(Sender: TObject);
    //procedure btnAuthorsDragOver(Sender, Source: TObject; X, Y: Integer; State: TDragState; var Accept: Boolean);
    procedure btnAuthorsDragOver(Sender: TObject; var Accept: Boolean);
    //procedure btnAuthorsDragDrop(Sender, Source: TObject; X, Y: Integer);
    procedure btnAuthorsDragDrop(Sender: TObject);
    procedure timerFishTimer(Sender: TObject);
    procedure FishImageClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure imgDonateClick(Sender: TObject);
  private
    procedure LoadText;
  end;

implementation

uses
  LCLIntf, devcfg, utils, MultiLangSupport;

{$R *.lfm}

procedure TAboutForm.LoadText;
begin
  // Set interface font
  Font.Name := devData.InterfaceFont;
  Font.Size := devData.InterfaceFontSize;
  lblVersion.Font.Size := devData.InterfaceFontSize + 2;

  Caption := Lang[ID_AB_CAPTION];
  lblLicense.Caption := Lang[ID_AB_LICENSE];
  grpLinks.Caption := Lang[ID_AB_WEBCAP];

  lblWebsite.Caption := Lang[ID_AB_WEBSITE];
  if Pos('Chinese', devData.Language) > 0 then
    lblWebSiteURL.Caption := 'https://gitee.com/devcpp/devcpp'  //'https://devcpp.gitee.io'  //'https://banzhusoft.github.io/devcpp-cn/'
  else
    lblWebSiteURL.Caption := 'https://anbangli.github.io/XiaoLoong-DevCpp/';


  lblEmail.Caption := Lang[ID_AB_EMAIL];

  lblPost4992.Caption := Lang[ID_AB_POST4992];
  lblRepository.Caption := Lang[ID_AB_REPOSITORY];
  lblSubreddit.Caption := Lang[ID_AB_SUBREDDIT];
  lblBlog.Caption := Lang[ID_AB_BLOGNAME];
  lblCompilers.Caption := Lang[ID_AB_COMPILERS];
  lblMinGW.Caption := Lang[ID_AB_LBLMINGWSITE];
  lblTDM.Caption := Lang[ID_AB_TDMGCC];
  lblPre4992.Caption := Lang[ID_AB_PRE4992];
  lblBlood.Caption := Lang[ID_AB_LBLBLOODSITE];
  //lblDiscussion.Caption := Lang[ID_AB_LBLFORUM];
  //lblMailing.Caption := Lang[ID_AB_LBLMAIL];
  lblResources.Caption := Lang[ID_AB_LBLEMAIL];
  btnOk.Caption := Lang[ID_BTN_OK];
  btnUpdateCheck.Caption := Lang[ID_AB_UPDATE];
  btnAuthors.Caption := Lang[ID_BTN_AUTHOR];
end;

procedure TAboutForm.URLLabelClick(Sender: TObject);
var
  S: String;
begin
  S := TLabel(Sender).Caption;
  OpenURL(s);
end;

procedure TAboutForm.FormCreate(Sender: TObject);
var
  datestring: String;
begin
  LoadText;

  // Use modified time, not the PE headers
  datestring := GetBuildTime(ParamStr(0));
  lblVersion.Caption := lblVersion.Caption + DEVCPP_VERSION;
  lblBuild.Caption := 'Build time: ' + datestring;

  if FileExists(devData.Splash) then // TODO: check all folders?
    imgBanner.Picture.LoadFromFile(devData.Splash);
end;

procedure TAboutForm.btnAuthorsClick(Sender: TObject);
const
  MessageText =
    'Authors:'#13#10#13#10 +
    '- v5.13 and later development: Anbang Li'#13#10 +
    '- Post-4.9.9.2 development: Johan Mes'#13#10 +
    '- Development: Colin Laplace, Mike Berg, Hongli Lai, Yiannis Mandravellos'#13#10 +
    '- Contributors: Peter Schraut, Marek Januszewski, Anonymous'#13#10 +
    '- TDM-GCC compiler: J.M. Eubank'#13#10 +
    '- MinGW compiler system: Mumit Khan, J.J. van der Heijden, Colin Hendrix and GNU developers'#13#10 +
    '- Splash screen and association icons: Matthijs Crielaard'#13#10 +
    //'- New Look theme: Gerard Caulfield'#13#10 +
    '- Basic Outline theme: Basic User Interface, Linecon, APP Custom UI, Essentials, ' +
    'Web User Interface, Media, Arrow Outline, Anbang Li, etc.'#13#10 +
    '- FatCow Modern theme: FatCow, Crystal Project, Anbang Li'; //#13#10 +
    //'- Gnome icons: Gnome designers'#13#10 +
    //'- Blue theme: Thomas Thron';
begin
  MessageBeep($F);
  MessageDlg(MessageText, MtInformation, [MbOK], 0);
end;

//procedure TAboutForm.btnAuthorsDragOver(Sender, Source: TObject; X,
//  Y: Integer; State: TDragState; var Accept: Boolean);
procedure TAboutForm.btnAuthorsDragOver(Sender: TObject; var Accept: Boolean);
begin
  Accept := True;
end;

//procedure TAboutForm.btnAuthorsDragDrop(Sender, Source: TObject; X, Y: Integer);
procedure TAboutForm.btnAuthorsDragDrop(Sender: TObject);
begin
  pnlFish.Left := 0 - pnlFish.Width;
  pnlFish.Top := Random(Height - pnlFish.Height - (pnlFish.Height div 3));
  pnlFish.Tag := 0;
  timerFish.Enabled := True;
end;

procedure TAboutForm.timerFishTimer(Sender: TObject);
begin
  if ((pnlFish.Tag = 0) and (pnlFish.Left > Width + 10)) or
    ((pnlFish.Tag <> 1) and (pnlFish.Left < 0 - pnlFish.Width - 10)) then
    timerFish.Enabled := False;

  if pnlFish.Tag = 0 then
    pnlFish.Left := pnlFish.Left + 5
  else
    pnlFish.Left := pnlFish.Left - 5;
  pnlFish.Top := pnlFish.Top + 1;
end;

procedure TAboutForm.FishImageClick(Sender: TObject);
begin
  pnlFish.Tag := not pnlFish.Tag;
end;

procedure TAboutForm.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  CloseAction := caFree;
end;


procedure TAboutForm.imgDonateClick(Sender: TObject);
begin
  OpenURL('https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7FD675DNV8KKJ');
end;



end.


//Dev-C++ Discussion Forum: http://www.bloodshed.net/forum/
//Dev-C++ Users Mailing List: http://www.bloodshed.net/devcpp-ml.html

