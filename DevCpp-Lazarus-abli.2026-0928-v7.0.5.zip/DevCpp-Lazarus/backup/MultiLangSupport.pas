{
    This file is part of Dev-C++
    Copyright (c) 2004 Bloodshed Software

    Dev-C++ is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Dev-C++ is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Dev-C++; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
}

unit MultiLangSupport;

{$MODE Delphi}

interface

uses
  LCLIntf, LCLType, LMessages, Dialogs, SysUtils, Classes;

{$I LangIDs.inc}

type
  TdevMultiLangSupport = class(TObject)
  private
    fLangList: TStringList;
    fLangListLoaded: Boolean;
    fLangFile: String;
    fCurLang: String;
    fStrings: TStringList;
    fMessage: TStringList;
    fDefaultLangStrings: TStringList;
    function GetString(ID: integer): String;
    function GetLangName: String;
  public
    constructor Create;
    destructor Destroy; override;
    procedure SelectLanguage;
    procedure CheckLanguageFiles;
    procedure Open(const FileName: String);
    procedure LoadTrans(const FileName: String; var strList: TStringList);
    procedure SetLang(const Lang: String);
    function GetLangList: TStringList;
    function FileFromDescription(const Desc: String): String;
    property Strings[index: integer]: String read GetString; default;
    property CurrentLanguage: String read GetLangName;
    property Langs: TStringList read GetLangList;
  end;

function Lang: TdevMultiLangSupport;

implementation

uses
  LangFrm, Forms, Utils, Version, Controls, devCFG;

var
  fLangSingleton: TdevMultiLangSupport = nil;

function Lang: TdevMultiLangSupport;
begin
  if not Assigned(fLangSingleton) and not Application.Terminated then
    fLangSingleton := TdevMultiLangSupport.Create;
  Result := fLangSingleton;
end;

constructor TdevMultiLangSupport.Create;
var
  DefaultLangFile: String;
begin
  inherited;
  fLangList := TStringList.Create;
  fLangListLoaded := False; // only load when needed
  fStrings := TStringList.Create;
  fMessage := TStringList.Create;
  fDefaultLangStrings := TStringList.Create;

  // Load default english file from languages directory
  DefaultLangFile := ValidateFile('English.lng', devDirs.Lang);
  if DefaultLangFile = '' then begin
    MessageDlg('Could not open language file English.lng', mtError, [mbOK], 0);
  end else begin
    fDefaultLangStrings.LoadFromFile(DefaultLangFile);
  end;
end;

destructor TdevMultiLangSupport.Destroy;
begin
  FreeAndNil(fLangList);
  FreeAndNil(fStrings);
  FreeAndNil(fMessage);
  FreeAndNil(fDefaultLangStrings);
  fLangSingleton := nil;
  inherited;
end;

procedure TdevMultiLangSupport.Open(const Filename: String);
var
  LangFile: String;
  MS: TMemoryStream;
  Buf: PAnsiChar;
  BufLen: Integer;
begin
  // Load file from languages directory
  LangFile := ValidateFile(Filename, devDirs.Lang);
  if LangFile = '' then begin
    MessageDlg('Could not open language file ' + Filename, mtError, [mbOK], 0);
    Exit;
  end;

  // Load file into fStrings
  // Read raw bytes and convert to UTF-8 via AnsiBytesToUnicode,
  // which auto-detects UTF-8 vs ANSI encoding
  MS := TMemoryStream.Create;
  try
    MS.LoadFromFile(LangFile);
    Buf := MS.Memory;
    BufLen := MS.Size;
    if (Buf <> nil) and (BufLen > 0) then
      fStrings.Text := String(AnsiBytesToUnicode(Buf, BufLen))
    else
      fStrings.Clear;
  finally
    MS.Free;
  end;

  fLangFile := LangFile;

  // Get languange
  fCurLang := fStrings.Values['Lang'];
  if fCurLang = '' then
    fCurLang := ChangeFileExt(ExtractFileName(LangFile), '');
  devData.Language := ExtractFileName(LangFile);

end;

procedure TdevMultiLangSupport.LoadTrans(const Filename: String; var strlist: TStringList);
var
  TransFile: String;
  MS: TMemoryStream;
  Buf: PAnsiChar;
  BufLen: Integer;
begin
  // Load file from languages directory
  TransFile := ValidateFile(Filename, devDirs.Lang);
  TransFile := ChangeFileExt(TransFile, '.trans.txt');
  if FileExists(TransFile) then begin
    // Read raw bytes and convert to UTF-8 via AnsiBytesToUnicode,
    // which auto-detects UTF-8 vs ANSI encoding
    MS := TMemoryStream.Create;
    try
      MS.LoadFromFile(TransFile);
      Buf := MS.Memory;
      BufLen := MS.Size;
      if (Buf <> nil) and (BufLen > 0) then
        strlist.Text := String(AnsiBytesToUnicode(Buf, BufLen))
      else
        strlist.Clear;
    finally
      MS.Free;
    end;
    if strlist.Count > 0 then
      strlist.Delete(0);
  end;
end;


procedure TdevMultiLangSupport.CheckLanguageFiles;
var
  I: integer;
  s: String;
  sl: TStringList;
begin
  try
    fLangList.Clear;
    if devDirs.Lang = '' then
      Exit;

    // Load list of all files
    FilesFromWildcard(devDirs.Lang, '*.lng', fLangList, False, False, True);
    if fLangList.Count > 0 then begin
      fLangList.Sort;
      sl := TStringList.Create;
      try
        for I := 0 to fLangList.Count - 1 do begin
          sl.LoadFromFile(fLangList[I]);
          s := sl.Values['Lang'];
          if SameText(ExtractFileName(fLangList[I]), 'English.lng') and (devData.Language = '') then
            fCurLang := s;
          if s = '' then
            fLangList[I] := format('%s=%s', [fLangList[I], ChangeFileExt(ExtractFileName(fLangList[I]), '')])
          else
            fLangList[I] := format('%s=%s', [fLangList[I], s]);
        end;
      finally
        sl.Free;
      end;
    end;
    if fCurLang = '' then
      fCurLang := devData.Language;
  finally
    fLangListLoaded := True;
  end;
end;

function TdevMultiLangSupport.GetString(ID: integer): String;
begin
  result := fStrings.Values[IntToStr(ID)];
  if Result = '' then
    Result := fDefaultLangStrings.Values[IntToStr(ID)];
  if result = '' then
    result := format('<ID %d translation missing>', [ID])
  else
    result := StringReplace(result, '<CR>', #13#10, [rfReplaceAll]);
end;

function TdevMultiLangSupport.GetLangName: String;
begin
  result := fCurLang;
end;

procedure TdevMultiLangSupport.SelectLanguage;
begin
  with TLangForm.Create(nil) do try
    ShowModal;
  finally
    Free;
  end;
end;

procedure TdevMultiLangSupport.SetLang(const Lang: String);
var
  I: integer;
begin
  if SameText(Lang, fCurLang) then
    exit;
  if not fLangListLoaded then
    CheckLanguageFiles; // can be slow, so load on demand
  for I := 0 to fLangList.Count - 1 do
    if SameText(ExtractFileName(fLangList.Names[I]), Lang) then begin
      Open(fLangList.Names[I]);
      break;
    end;
end;

function TdevMultiLangSupport.FileFromDescription(const Desc: String): String;
var
  i: integer;
begin
  // returns the filename of the lang file described as Desc
  // for example with Desc="English (Original)", returns "English.lng"
  Result := Desc;
  if not fLangListLoaded then
    CheckLanguageFiles; // can be slow, so load on demand
  for i := 0 to fLangList.Count - 1 do
    if SameText(fLangList.ValueFromIndex[i], Desc) then begin
      Result := ExtractFilename(fLangList.Names[i]);
      Break;
    end;
end;

function TdevMultiLangSupport.GetLangList: TStringList;
begin
  if not fLangListLoaded then
    CheckLanguageFiles; // can be slow, so load on demand
  Result := fLangList;
end;

end.

