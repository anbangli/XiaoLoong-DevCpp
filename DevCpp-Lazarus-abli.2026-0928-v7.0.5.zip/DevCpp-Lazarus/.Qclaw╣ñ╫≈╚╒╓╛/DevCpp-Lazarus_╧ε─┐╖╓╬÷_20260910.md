# DevCpp-Lazarus 项目分析

> 分析对象：`c:\Users\Administrator\WorkBuddy\2026-DevCpp-Lazarus\DevCpp-Lazarus\`
> 分析日期：2026-09-10
> 结论摘要：这是 **Dev-C++（Bloodshed/Orwell 血统）被 XiaoLoong 团队迁移到 Lazarus/Free Pascal（Object Pascal）的 v7.0 版本**，是一个成熟、活跃开发中的 C/C++ IDE 工程。

---

## 1. 项目定位

| 项 | 值 |
|----|----|
| 名称 | XiaoLoong Dev-C++ (XL7) |
| 版本 | v7.0（`Version.pas` 中 `DEVCPP_VERSION = '7.0'`；lpi 版本信息 7.5.94，ProductVersion v7.0） |
| 血统 | Bloodshed Dev-C++ → Orwell Dev-C++ → XiaoLoong 迁移版 |
| 入口 | `DevCpp.lpr` |
| 工程文件 | `DevCpp.lpi`（Lazarus Project） |
| 主窗体 | `main.pas` → `TMainForm` |
| 框架 | Lazarus 4.x + Free Pascal 3.2.2（`{$MODE Delphi}` / objfpc） |
| 许可 | GPL v2+ |
| 输出目标 | `d:\cc\devcpp\release发行\DevCpp.exe`（打包产物另有 `DevCpp-7.0.exe`） |

**本质**：DevCpp 本身只是 IDE 外壳，实际编译/调试靠外部 MinGW GCC 工具链（gcc/g++/gdb/windres/make/gprof）。

---

## 2. 规模统计

- 总文件 859 个，约 24.5 MB（含资源/备份/词法/测试）。
- 顶层 `.pas` 源码 72 个，`.lfm` 窗体 39 个。
- 代码量（行数 Top）：
  - `main.pas` 8693 行 / 322 KB（中央调度器，最大单文件）
  - `Editor.pas` 3553 行 / 137 KB
  - `devcfg.pas` 3125 行 / 124 KB
  - `CppParser.pas` 2695 行 / 99 KB
  - `EditorOptFrm.pas` 2150 行 / 90 KB
  - `Project.pas` 1777 行、`Compiler.pas` 1337 行、`Utils.pas` 1329 行 ……
- 最大资源文件：`DataFrm.lfm` 851 KB（DataModule，含图片/工具栏位图列表）。

---

## 3. 技术栈与第三方依赖

Lazarus Online Package Manager 安装的依赖包（`DevCpp.lpi` RequiredPackages）：

| 包 | 用途 |
|----|------|
| **ATSynEdit**（atsynedit_package） | 现代化编辑器控件 `TATSynEdit`，CudaText 核心，替代 SynEdit |
| **ATSynEdit_Ex** | ATSynEdit 扩展 |
| **ATSynEdit_Cmp** | 组件集合 |
| **EControl**（econtrol_package） | 语法高亮引擎，配合 ATSynEdit |
| **EncConv**（encconv_package） | 字符编码转换 |
| Printer4Lazarus | 打印 |
| LCL | Lazarus 组件库 |

外部/辅助工具（`Tools/`）：`ConsolePauser.exe`（控制台暂停）、`DevCppPortable.exe`（便携模式）、`Packman.exe`（.pak 插件，遗留）、`GitPush.exe`、`KeywordHighlighter.exe`、`TextDiff.exe`。

词法文件（`lexers/`）：`C++.lcf`、`C.lcf`、`Fortran.lcf`、`Python.lcf`（EControl 着色/折叠定义，含 `.bak`/`.orig` 备份）。

---

## 4. 架构分层

```
DevCpp.lpr（入口：单例检测 / INI 路径解析 / 配置加载 / 主窗体）
        │
        ▼
main.pas (TMainForm) —— 中央调度器（菜单/编辑器管理/项目树/调试/编译/文件监控）
   ├─ Editor.pas (TEditor→TATSynEdit) + EditorList.pas   —— 编辑器
   ├─ Compiler.pas (TCompiler) + devrun.pas/devExec.pas  —— 编译执行
   ├─ Debugger.pas + DebugReader.pas (GDB 管道)          —— 调试
   ├─ Project.pas (TProject/TProjUnit) + ProjectTypes    —— 项目管理
   ├─ ClassBrowser / CodeCompletion / CodeToolTip        —— 智能编辑
   └─ CppParser → CppTokenizer + CppPreprocessor + StatementList —— C++ 解析
支撑层：devcfg.pas（全局配置 TdevData/TdevCompilerSet）、CFGData、ConfigData、
        Utils/CBUtils、Macros、devFileMonitor、ImageTheme、MultiLangSupport、LangIDs.inc
UI 层：约 40 个 *Frm.pas/.lfm（项目/编辑/搜索/环境/调试视图/导入导出等）
数据模块：DataFrm.pas → dmMain（图片、工具栏图像资源）
```

**设计特点**：事件驱动（大量 `procedure of object` 回调）；单例模式（Windows `FindWindow` / Linux 文件锁）；配置可移植（`-c <dir>` 便携模式）；最多 10 套编译器工具链配置。

---

## 5. 演进历史（三条迁移主线）

文档集中于 `docs/` 与根目录 `MIGRATION.md`：

1. **Delphi → Lazarus/FPC 平台迁移**（已完成）
   - SynEdit 2.1.1 → **ATSynEdit**：列有完整 API 对照表（`BufferCoord`→`Point`(0-based)、`CaretXY`→`CaretPos`、`SelText`→`TextSelected`、书签/折叠/缩进命令等），`Editor.pas` 与 `main.pas` 大范围重写。
   - `.dfm` → `.lfm` 格式批量转换（38 个）。
   - 导出功能（HTML/RTF/TEX）因 ATSynEdit 无 SynExporter 而**禁用**。

2. **Windows → Linux 移植**（Phase 1 + Phase 2 均标记完成，2026-07-16）
   - Phase 1 消除编译阻断：`Instances.pas`、`devFileMonitor.pas`、`ImageTheme.pas`、`devcfg.pas`、`DevCpp.lpr`、`Utils.pas` 及各 Form，全部 `ShellExecute`→`OpenURL`、Windows API 条件编译（`{$IFDEF MSWINDOWS}`）。
   - Phase 2 功能对齐：`devcfg.pas` PATH 注册、`Utils.pas` 文件关联、`FileAssocs.pas` 完整重写（Linux 用 XDG desktop 文件 + `xdg-mime`）、`main.pas` HiDPI 修复条件化。
   - Phase 3 暂缓项：编译输出路径解析、GDB 路径条件化、主题图标 XPM/PNG、外部帮助文档路径。

3. **界面/交互增强**（2026-08~09 持续）
   - 菜单 owner-draw（`main-ownerdraw.pas` 为实验副本）；外观主题（浅色/深色/跟随系统，`devData.AppearTheme`，`main.pas LoadColor`）。
   - 只读系统头文件（`IsSystemHeaderFile` + `ModeReadOnly`）。
   - 括号/引号配对高亮（`bracket_highlight_20260907.md`）：`()[]{}<>` 及 `""`/`''` 淡黄背景高亮，含字符串/注释/尖括号关系运算符排除逻辑。

---

## 6. 当前状态（2026-09）

- **可编译产出**：`d:\cc\devcpp\release发行\DevCpp.exe`（9.2 MB，构建于 2026-09-09 16:08），另有 `DevCpp-7.0.exe`、`DevCppPortable.exe`、安装脚本 `DevCpp-setup.iss`，捆绑多套 MinGW（13.2 / 15.3 / 16.1，含 win32/posix 变体）。
- **最近改动**（2026-09-09）：`DevCpp.lpi`、`DataFrm.lfm`、`main.pas/.lfm`、`FindFrm.pas`、`ProfileAnalysisFrm.pas`、`Debugger.pas`、`Project.pas`、`devcfg.pas`、`Editor.pas` 等顶层文件集中在 15:00–16:08 被更新。
- **备份机制**：非 Git，而是 `d:\cc\devcpp\` 下大量时间戳 zip（`DevCpp-Lazarus-abli.YYYYMMDD-HHMM[.tag].zip`），从 2026-06 起近乎每半日一次；本目录还有 `backup/`（百来个旧版 .pas/.lfm）。

---

## 7. 目录结构要点

| 路径 | 说明 |
|------|------|
| 根目录 `*.pas` / `*.lfm` | 72 个源文件 + 39 个窗体（核心代码） |
| `docs/` | `ARCHITECTURE.md`、`LINUX_PORT_PHASE1/2.md`、跨平台迁移 mhtml |
| `.workbuddy/memory/` | 开发日志（2026-06-11/12/29 + MEMORY.md，BrowserView 字号/行高与只读头文件修复记录） |
| `backup/` | 旧版本源文件快照（含 `*OptionsFrm`/`EnviroFrm` 旧命名） |
| `lexers/` | EControl `.lcf` 词法定界 + 转换脚本 `fix_c_lcf.py` |
| `Tests/` | 解析器测试用 C++ 源码（Parser/Explorer/Project/Folds/Document）+ `Fail.txt` |
| `Tools/` | 辅助工具（ConsolePauser.cpp、图标、Packman.map 等） |
| `Images/` | 主题图像（Gnome/Modern/NewLook）+ Logo/图标 |
| `output/`、`.Qclaw日志/`、`.workbuddy/` | 输出/日志/工作区元数据 |

---

## 8. 已知问题与待办（RISK/TODO）

来源：`!todo(orwell).txt`、`Tests/Fail.txt`、`MIGRATION.md` 剩余项、`ARCHITECTURE.md` §9。

**解析器测试失败（`Tests/Fail.txt`）**
- `operator int` 等转换运算符解析失败；声明与定义参数文本不完全一致时无法链接。
- Struct 中 enum 不在类浏览器显示；类名左侧悬停误显示构造函数提示。

**ATSynEdit 迁移剩余 TODO**
- `Editor.pas` 约 25 项、`main.pas` 约 16 项，主要涉及 EControl 高亮器适配、注释/取消注释命令（ATSynEdit 无内置）需手写、Gutter 字体模型、`dmMain.Cpp` 引用等。

**功能待办**
- HTML/RTF/TeX 导出（已禁用）、查找结果列表绘制优化、选中相同词高亮、文件重命名（MoveFile）、自定义关键词高亮、CPU 窗口跳帧、条件断点、D3D11 头/库、webupdate 代理。

**工程层面风险**
- **无版本控制（无 `.git`）**：依赖手工时间戳 zip 备份，协作/回滚/差异审查困难。
- **死代码/重复文件**：`main-ownerdraw.pas`（309 KB，未纳入 lpi）、`Utils.old.pas`、`backup/` 全量副本、`Tests/*.o/.ppu` 编译中间物混入。
- **路径硬编码**：构建目标写死 `d:\cc\devcpp\release发行\...`（含中文目录名），降低可移植性。
- **编码混杂**：`!WHATSNEW-abli.txt` 等中文文件以 GBK 保存，按 UTF-8 读取出现乱码；部分中文文件名在 PowerShell 下显示异常。
- **资源编译被禁用**：`.lpr` 中 `DefaultFiles.res`、`mainicon.res` 注释掉（注释说明"needs windres setup"）。
- 顶层文件夹名含 `.Qclaw日志`、`release发行` 等中文/特殊字符，跨平台（Linux）构建易出问题。

---

## 9. 总体评价

- 这是一个**移植完成度高、仍在积极迭代**的 IDE 重构工程：Delphi→Lazarus、SynEdit→ATSynEdit、Windows→Linux 三条主线均已有阶段成果文档，且能产出可运行的 9 MB 发布版。
- 架构分层清晰（UI / 业务 / 解析 / 数据 / 工具），核心解析器（CppParser+Tokenizer+Preprocessor+StatementList）与编辑器封装完整度较高。
- 主要短板在**工程管理**（无 Git、备份冗余、死文件、硬编码路径、编码不统一）与**残留 TODO**（高亮器适配、注释命令、导出）。后续若引入 Git、清理 `backup/`/`main-ownerdraw.pas`/中间物、统一 UTF-8 与相对路径，可显著降低维护成本。
