# Linux 移植可行性评估报告
**项目**：Orwelldevcpp（Lazarus 迁移版，Delphi/SynEdit → Lazarus/ATSynEdit）  
**评估日期**：2026-07-16  
**评估范围**：全部 25+ 个 Pascal 源文件及项目配置

---

## 一、总体评估

| 维度 | 评级 | 说明 |
|------|------|------|
| **语法/框架兼容性** | 🟡 中等 | LCL 基本跨平台，但大量 `Windows` 单元硬依赖需重构 |
| **核心编辑功能** | 🟢 高 | 编辑器、语法高亮、代码补全、类浏览器均在纯 Pascal/LCL 层 |
| **编译/构建** | 🟡 中等 | Makefile.win 需改为 Linux 版本；MinGW 工具链需替换为 Linux GCC/GDB |
| **调试功能** | 🟡 中等 | GDB 本身跨平台，但 `Debugger.pas` 底层进程管理为 Windows API |
| **文件关联/单实例** | 🔴 高风险 | 完全基于 Windows Registry + Mutex，无条件编译 |
| **GUI Shell 集成** | 🔴 高风险 | `ShellExecute` 直接调用 Windows Explorer |
| **移植工作量估算** | — | 中等偏高（估计 **3~6 人月**，不含工具链适配） |

---

## 二、不可编译单元（直接阻止 Linux 编译）

### 1. `Instances.pas` — 单实例检测（完全不可用）

**现状**：零条件编译，100% Windows API

| 代码 | 问题 |
|------|------|
| `CreateMutex` | Windows Mutex API，Linux 无此 API |
| `EnumWindows` | Windows 窗口枚举，Linux 无等效 |
| `OpenProcess(PROCESS_QUERY_INFORMATION or PROCESS_VM_READ, ...)` | Windows 进程 API |
| `GetModuleFileNameExW` from `psapi.dll` | Windows 专用 DLL |
| `SendMessage(..., WM_COPYDATA, ...)` | Windows 进程间通信协议 |
| `GetWindowLong(Handle, GWL_HINSTANCE)` | Windows 窗口属性 API |
| `GetWindowThreadProcessId` | Windows 进程 ID 查询 |

**移植方案**（选一）：
- **D-Bus 激活**：Linux 标准单实例机制，跨发行版通用（推荐）
- **文件锁**：`/tmp/dev-cpp-{uid}.lock`，简单但不如 D-Bus 优雅
- **Unix Domain Socket**：比文件锁更可靠，略复杂

**改造方式**：新增 `Instances.pas`（Linux 版）或在原文件中加 `{$IFDEF MSWINDOWS}` 包裹

---

### 2. `devFileMonitor.pas` — 文件监控（条件编译存在但不完整）

**现状**：有 `{$IFDEF MSWINDOWS}` 包裹，但无对应 Linux 实现

```pascal
uses
{$IFDEF MSWINDOWS}
  Windows, Messages,
{$ENDIF}
  SysUtils, ...
```

Linux 下需要用 `inotify`（glibc）或 `fpnotify`（FreePascal 的跨平台封装）替代 `ReadDirectoryChangesW`。

**改造方式**：
```pascal
{$IFDEF MSWINDOWS}
  // 现有 Windows 实现
{$ELSE}
  // 使用 fpnotify 或 inotify 直接实现
{$ENDIF}
```

---

### 3. `ImageTheme.pas` — 图标主题加载（Windows GDI）

**现状**：使用 Windows GDI 函数

| 代码 | 说明 |
|------|------|
| `StretchBlt` | Windows 位图拉伸 |
| `CreateCompatibleDC` | Windows 设备上下文 |
| `CreateDIBSection` | Windows DIB 创建 |
| `SelectObject` / `DeleteObject` | Windows GDI 对象管理 |

**改造方式**：重写为使用 LCL 的 `TBitmap` / `TLazCanvas`，完全跨平台：

```pascal
uses
  LCLType, LCLIntf, Graphics;  // 移除 Windows

procedure TCustomImageTheme.LoadTheme(const Filename: String);
var
  Bmp: TBitmap;
begin
  Bmp := TBitmap.Create;
  try
    Bmp.LoadFromFile(Filename);
    FBitmap.Assign(Bmp);
  finally
    Bmp.Free;
  end;
end;
```

---

## 三、不可运行功能（编译通过但行为错误）

### 4. `DevCpp.lpr` — 入口点：配置目录路径

**现状**：使用 `SHGetFolderPath(CSIDL_APPDATA)` 获取配置目录

```pascal
if SUCCEEDED(SHGetFolderPath(0, CSIDL_APPDATA, 0, 0, Buffer)) then
  AppData := IncludeTrailingBackslash(Buffer);
devData.INIFileName := AppData + 'Dev-Cpp\' + INIFileName;
```

**Linux 等效路径**：
- 优先：`$XDG_CONFIG_HOME/Dev-Cpp/`（即 `~/.config/Dev-Cpp/`）
- 回退：`$HOME/.config/Dev-Cpp/`

**改造方式**：
```pascal
uses
{$IFDEF MSWINDOWS}
  Windows, SHFolder,
{$ENDIF}
  SysUtils;

{$IFDEF MSWINDOWS}
  // 现有 SHGetFolderPath 逻辑
{$ELSE}
  AppData := GetEnvironmentVariable('XDG_CONFIG_HOME');
  if AppData = '' then
    AppData := GetEnvironmentVariable('HOME') + '/.config';
  devData.INIFileName := AppData + '/Dev-Cpp/' + INIFileName;
{$ENDIF}
```

---

### 5. `main.pas` — 多处 `ShellExecute` 调用

**现状**：共 7+ 处 `ShellExecute`，硬编码调用 Windows 组件：

| 行 | 功能 | 替换方案 |
|----|------|----------|
| ~7328 | 打开外部程序 | `LCLIntf.OpenDocument` |
| ~7335 | 同上 | `LCLIntf.OpenDocument` |
| ~8109 | 打开 HTML | `LCLIntf.OpenURL` |
| ~8530/8535/8557 | 打开文件 | `LCLIntf.OpenDocument` |
| ~8568 | 打开文件夹 | `LCLIntf.OpenDocument`（Linux 会用文件管理器） |
| ~8665 | Explorer 打开目录 | 替换为 `xdg-open` 或 `LCLIntf.OpenDocument` |

**示例**：
```pascal
// Windows（现有）
ShellExecute(0, 'open', PChar(s), nil, nil, SW_SHOWNORMAL);

// 跨平台替换
LCLIntf.OpenDocument(s);  // LCL 自动选择合适的 Linux 程序
```

> ⚠️ 注意：`LCLIntf.OpenDocument` 在 Windows 上等价于 `ShellExecute`，在 Linux 上调用 `xdg-open`/`gio open`，在 macOS 上调用 `open`。**完全兼容，无需条件编译。**

---

### 6. `devcfg.pas` — `TdevDirs.SettoDefaults` 中的 `SHGetSpecialFolderPath`

**现状**：获取"我的文档"目录作为默认保存路径

```pascal
if SHGetSpecialFolderPath(Application.Handle, DocumentsPath, CSIDL_MYDOCUMENTS, false) then
  fDefault := DocumentsPath
else
  fDefault := fExec;
```

**Linux 等效**：`$XDG_DOCUMENTS_DIR` 或 `$HOME/Documents`

```pascal
{$IFDEF MSWINDOWS}
  SHGetSpecialFolderPath(...);
{$ELSE}
  fDefault := GetEnvironmentVariable('XDG_DOCUMENTS_DIR');
  if fDefault = '' then
    fDefault := GetEnvironmentVariable('HOME') + '/Documents';
{$ENDIF}
```

---

### 7. `devcfg.pas` — `RemoveOptionsDir` 使用 `SHFILEOPSTRUCT`

**现状**：使用 Windows Shell 文件操作 API 执行"带备份的删除"

```pascal
fostruct: SHFILEOPSTRUCT;
FillChar(fostruct, Sizeof(fostruct), 0);
with fostruct do begin
  Wnd := 0;
  pFrom := @DirFrom;
  pTo := @DirTo;
  wFunc := FO_MOVE;  // 先移动到 Backup
end;
FileOperation(fostruct);
```

**Linux 等效**：FreePascal 的 `SysUtils.DeleteFile` + `RenameFile`，或使用 `TFileOperation`（LCL 跨平台封装）

---

### 8. `devcfg.pas` + `FileAssocs.pas` — Windows Registry 文件关联

**现状**：文件关联完全基于 `TRegistry` 写 `HKEY_CLASSES_ROOT`

**Linux 等效**：freedesktop.org `.desktop` 文件标准

| 操作 | Windows 实现 | Linux 实现 |
|------|------------|------------|
| 读取关联 | `TRegistry.OpenKey(...)` | 解析 `~/.local/share/applications/mimeapps.list` |
| 写入关联 | `TRegistry.WriteString(...)` | 创建 `$HOME/.local/share/applications/dev-cpp*.desktop` |

**改造方式**：
- `FileAssocs.pas` 需要完全重写或用 `{$IFDEF MSWINDOWS}` 包裹
- 新增 `FileAssocsUnix.pas` 处理 `.desktop` 文件的读/写/注册

---

## 四、已修复/无需修改的区域

| 模块 | 状态 | 说明 |
|------|------|------|
| **编辑器核心**（`Editor.pas`） | ✅ 跨平台 | 使用 ATSynEdit + LCL，天然跨平台 |
| **代码补全**（`CodeCompletion.pas`） | ✅ 跨平台 | 纯 Pascal + C++ 解析 |
| **类浏览器**（`ClassBrowser.pas`） | ✅ 跨平台 | 纯 Pascal |
| **语法高亮**（ATSynEdit + EControl） | ✅ 跨平台 | 平台无关 |
| **项目文件**（`Project.pas`） | ✅ 跨平台 | `.dev` 格式基于 `TIniFile` |
| **编译器集成**（`Compiler.pas`） | ✅ 跨平台 | 调用外部工具链，与平台无关 |
| **调试器 GDB**（`Debugger.pas`） | ✅ 跨平台 | GDB 本身跨平台；`CreateProcessW` 已修 |
| **消息框**（多处） | ✅ 跨平台 | `Application.MessageBox` 跨平台 |
| **工具函数**（`Utils.pas`） | ✅ 跨平台 | `RunAndGetOutput` 已用 `CreateProcessW` |
| **路径常量**（`Version.pas`） | ✅ 跨平台 | `pd` 已用 `{$IFDEF MSWINDOWS}` 区分 |
| **编码处理** | ✅ 跨平台 | `AnsiBytesToUnicode` 已修复 UTF-8 |

---

## 五、工具链适配（编译/调试依赖）

| 组件 | Windows | Linux |
|------|---------|-------|
| C/C++ 编译器 | MinGW GCC | 系统 GCC（`apt install build-essential`） |
| GDB 调试器 | MinGW GDB | 系统 GDB（`apt install gdb`） |
| Make | `mingw32-make.exe` | GNU Make（`apt install make`） |
| 资源编译器 | MinGW windres | 系统 `windres`（binutils） |
| 语法检查 | `gcc -fsyntax-only` | 同上 |
| 性能分析 | MinGW gprof | 系统 gprof |

**Makefile.win** → 需要新增 `Makefile.linux`：
```makefile
CC = gcc
CXX = g++
CFLAGS = -Wall -g
```

**配置界面**（工具链路径设置）需要：
- Windows：识别 `C:\MinGW\bin\gcc.exe`
- Linux：识别 `/usr/bin/gcc`

---

## 六、移植路线图

### Phase 1：编译通过（核心阻断修复）
**预计 2~3 周**

1. `Instances.pas` → 替换为文件锁或 D-Bus（可选先跳过单实例功能）
2. `devFileMonitor.pas` → 添加 `{$ELSE}` 分支使用 `fpnotify`
3. `ImageTheme.pas` → 重写为 LCL `TBitmap`
4. `DevCpp.lpr` → 添加 Linux 配置路径逻辑
5. `devcfg.pas` → `SHGetSpecialFolderPath` → Linux 路径
6. `devcfg.pas` → `SHFILEOPSTRUCT` → `TFileOperation`
7. `main.pas` → `ShellExecute` → `LCLIntf.OpenDocument`（**无需条件编译**）

### Phase 2：功能完整（Linux 行为对齐）
**预计 2~4 周**

8. `FileAssocs.pas` → 新增 Linux 文件关联支持
9. `Compiler.pas` → 检测操作系统，调用对应的 `make` / `gcc`
10. `devcfg.pas` → 检测 MinGW vs 系统 GCC，设置默认工具链
11. `devcfg.pas` → Linux 下默认 GCC 路径 `/usr/bin/`
12. `Debugger.pas` → 检测 `gdb` 路径（Windows MinGW GDB vs Linux GDB）

### Phase 3：打磨（可选但推荐）
**预计 1~2 周**

13. 应用菜单（`.desktop` 文件）自动注册
14. Linux 下的临时文件目录（`/tmp/dev-cpp-*`）
15. `SHGetSpecialFolderPath` 替代方案：使用 `GetAppConfigDir`（FreePascal 跨平台封装）
16. 单元测试框架覆盖核心路径

---

## 七、已知移植障碍总结

```
阻塞等级说明：
  🔴 编译错误    → 直接阻止 Linux 编译
  🟡 功能错误    → 编译通过但行为异常
  🟢 已兼容/无需修改
```

| # | 文件 | 问题 | 等级 |
|---|------|------|------|
| 1 | `Instances.pas` | 100% Windows API，无条件编译 | 🔴 |
| 2 | `devFileMonitor.pas` | `{$IFDEF}` 存在但无 `{$ELSE}` 实现 | 🔴 |
| 3 | `ImageTheme.pas` | Windows GDI 位图操作 | 🔴 |
| 4 | `DevCpp.lpr` | `SHGetFolderPath` + `%APPDATA%` 路径 | 🟡 |
| 5 | `main.pas` | 7+ 处 `ShellExecute` | 🟡 |
| 6 | `devcfg.pas` | `SHGetSpecialFolderPath` | 🟡 |
| 7 | `devcfg.pas` | `SHFILEOPSTRUCT` 文件操作 | 🟡 |
| 8 | `FileAssocs.pas` | `TRegistry` 写文件关联 | 🟡 |
| 9 | `devcfg.pas` | `TRegistry` 读文件关联 | 🟡 |
| 10 | `Compiler.pas` | MinGW 路径默认配置 | 🟡 |

---

## 八、结论

**结论：技术可行，工作量中等偏高。**

| 方面 | 评估 |
|------|------|
| **最大风险** | `Instances.pas`（无任何条件编译保护）和文件关联（Registry → freedesktop.org） |
| **最大优势** | 核心功能（编辑器、C++解析、补全、类浏览）均为纯 Pascal/LCL，已天然跨平台 |
| **现实预估** | 认真处理 Phase 1（2~3 周）后，可得到一个 **基本可用的 Linux 版本** |
| **跨平台收益** | 代码基质更干净（Windows/Unicode 问题也在此过程中一并修复）、macOS 移植难度与 Linux 相当 |

> **建议**：将 `{$IFDEF MSWINDOWS}` 条件编译作为此次移植的核心改造框架，一次性完成所有平台差异隔离，为未来 macOS 支持留下接口。
