{
    This file is part of Dev-C++
    Copyright (c) 2004 Bloodshed Software

    Dev-C++ is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    Dev-C++ is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Dev-C++; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
}

unit Macros;

interface

uses
  SysUtils, devCfg, Version;

function ParseMacros(Str: String): String;

implementation

uses
  Main, editor, Dialogs, Classes;

procedure Replace(var Str: String; Old, New: String);
begin
  Str := StringReplace(Str, Old, New, [rfReplaceAll]);
end;

function ParseMacros(Str: String): String;
var
  e: TEditor;
  windir: string;
  pfdir: string;

begin
  Result := Str;
  e := MainForm.EditorList.GetEditor;
  //GetSystemDirectory(windir, MAX_PATH);
  windir:= GetEnvironmentVariable('WINDIR');
  pfdir := GetEnvironmentVariable('PROGRAMFILES');


  Replace(Result, '<DEFAULT>', devDirs.Default);
  Replace(Result, '<DEVCPP>', ExtractFileDir(ParamStr(0)));
  Replace(Result, '<DEVCPPVERSION>', DEVCPP_VERSION);
  Replace(Result, '<EXECPATH>', devDirs.Exec);
  Replace(Result, '<DATE>', DateToStr(Now));
  Replace(Result, '<DATETIME>', DateTimeToStr(Now));
  //Replace(Result, '<DATETIME>', FormatDateTime(Lang[ID_ITEM_DATETIMEFORMAT], Now));


  Replace(Result, '<WINDIR>', WINDIR);
  Replace(Result, '<PROGRAMFILES>', PFDIR);




  // Only provide the first cpp dir
  with devCompilerSets.CompilationSet do begin
    if Assigned(devCompilerSets.CompilationSet) and (CppDir.Count > 0) then
      Replace(Result, '<INCLUDE>', CppDir[0])
    else
      Replace(Result, '<INCLUDE>', '');

    // Only provide the first lib dir
    if Assigned(devCompilerSets.CompilationSet) and (LibDir.Count > 0) then
      Replace(Result, '<LIB>', LibDir[0])
    else
      Replace(Result, '<LIB>', '');
  end;

  // Project-dependent macros
  if Assigned(MainForm.Project) then begin
    Replace(Result, '<EXENAME>', MainForm.Project.Executable);
    Replace(Result, '<PROJECTNAME>', MainForm.Project.Name);
    Replace(Result, '<PROJECTFILE>', MainForm.Project.FileName);
    Replace(Result, '<PROJECTPATH>', MainForm.Project.Directory);
    Replace(Result, '<SOURCESPCLIST>', MainForm.Project.ListUnitStr(' '));
  end else if Assigned(e) then begin // Non-project editor macros
    Replace(Result, '<EXENAME>', '"' + ChangeFileExt(AnsiString(e.FileName), EXE_EXT) + '"');
    Replace(Result, '<PROJECTNAME>', AnsiString(e.FileName));
    Replace(Result, '<PROJECTFILE>', AnsiString(e.FileName));
    Replace(Result, '<PROJECTPATH>', ExtractFilePath(AnsiString(e.FileName)));
    Replace(Result, '<SOURCESPCLIST>', ''); // clear unchanged macros
  end else begin // clear unchanged macros
    Replace(Result, '<EXENAME>', '');
    Replace(Result, '<PROJECTNAME>', '');
    Replace(Result, '<PROJECTFILE>', '');
    Replace(Result, '<PROJECTPATH>', '');
    Replace(Result, '<SOURCESPCLIST>', '');
  end;

  // Editor macros
  if Assigned(e) then begin
    Replace(Result, '<SOURCENAME>', AnsiString(e.FileName));
    Replace(Result, '<SOURCENAME>', ExtractFilePath(AnsiString(e.FileName)));
    Replace(Result, '<WORDXY>', e.GetWordAtPosition(Point(e.Text.Carets[0].PosX, e.Text.Carets[0].PosY), wpInformation));
  end else begin // clear unchanged macros
    Replace(Result, '<SOURCENAME>', '');
    Replace(Result, '<SOURCENAME>', '');
    Replace(Result, '<WORDXY>', '');
  end;
end;

end.

